/**
 * PRAIA FIGHTERS — COMPETITIVE EDITION
 * Engine 100% Vanilla JS + HTML5 Canvas + Audio()
 */

// ==========================================
// 1. MOTOR DE ÁUDIO USANDO Audio()
// ==========================================
class SoundEngine {
    constructor() {
        this.sounds = {};
        try {
            this.sounds = {
                punch: this.createSound(190, 0.11, 'sawtooth', 85),
                kick: this.createSound(135, 0.17, 'square', 48),
                sweep: this.createSound(110, 0.22, 'sawtooth', 38),
                block: this.createSound(480, 0.09, 'triangle', 620),
                parry: this.createSound(880, 0.20, 'sine', 1320),
                dash: this.createSound(320, 0.10, 'triangle', 160),
                special: this.createSound(240, 0.42, 'sawtooth', 780),
                jump: this.createSound(260, 0.14, 'sine', 520),
                ko: this.createSound(110, 0.55, 'sawtooth', 30),
                start: this.createSound(440, 0.25, 'triangle', 660)
            };
        } catch (e) {}
    }

    createSound(startFreq, duration, type, endFreq) {
        const sampleRate = 22050;
        const numSamples = Math.floor(sampleRate * duration);
        const buffer = new ArrayBuffer(44 + numSamples * 2);
        const view = new DataView(buffer);

        const writeString = (offset, str) => {
            for (let i = 0; i < str.length; i++) {
                view.setUint8(offset + i, str.charCodeAt(i));
            }
        };

        writeString(0, 'RIFF');
        view.setUint32(4, 36 + numSamples * 2, true);
        writeString(8, 'WAVE');
        writeString(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        writeString(36, 'data');
        view.setUint32(40, numSamples * 2, true);

        let phase = 0;
        for (let i = 0; i < numSamples; i++) {
            const t = i / numSamples;
            const freq = startFreq + (endFreq - startFreq) * t;
            const envelope = Math.pow(1 - t, 1.5);
            phase += (2 * Math.PI * freq) / sampleRate;

            let sample = 0;
            if (type === 'sine') sample = Math.sin(phase);
            else if (type === 'square') sample = Math.sin(phase) >= 0 ? 1 : -1;
            else if (type === 'sawtooth') sample = 2 * ((phase / (2 * Math.PI)) % 1) - 1;
            else if (type === 'triangle') sample = Math.asin(Math.sin(phase)) * (2 / Math.PI);

            const val = Math.max(-1, Math.min(1, sample * envelope * 0.45));
            view.setInt16(44 + i * 2, val * 32767, true);
        }

        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return new Audio('data:audio/wav;base64,' + btoa(binary));
    }

    play(name) {
        const sfx = this.sounds[name];
        if (!sfx) return;
        try {
            const clone = sfx.cloneNode();
            clone.volume = 0.6;
            clone.play().catch(() => {});
        } catch (e) {}
    }
}

// ==========================================
// 2. LOCALSTORAGE (RECORDS)
// ==========================================
const StorageManager = {
    KEY: 'praia_fighters_records_v1',
    get() {
        try {
            const raw = localStorage.getItem(this.KEY);
            return raw ? JSON.parse(raw) : { p1Wins: 0, p2Wins: 0 };
        } catch (e) {
            return { p1Wins: 0, p2Wins: 0 };
        }
    },
    addWin(playerNum) {
        const data = this.get();
        if (playerNum === 1) data.p1Wins++;
        else data.p2Wins++;
        try {
            localStorage.setItem(this.KEY, JSON.stringify(data));
        } catch (e) {}
        return data;
    }
};

// ==========================================
// 3. PROJÉTIL DE GOLPE ESPECIAL
// ==========================================
class SpecialProjectile {
    constructor({ owner, x, y, facing, color }) {
        this.owner = owner;
        this.x = x;
        this.y = y;
        this.facing = facing;
        this.color = color;
        this.vx = facing * 10.5;
        this.radius = 24;
        this.active = true;
    }

    update(canvasWidth) {
        this.x += this.vx;
        if (this.x < -40 || this.x > canvasWidth + 40) {
            this.active = false;
        }
    }

    getHitbox() {
        return {
            x: this.x - this.radius,
            y: this.y - this.radius,
            width: this.radius * 2,
            height: this.radius * 2
        };
    }

    draw(ctx) {
        ctx.save();
        ctx.translate(this.x, this.y);

        const grad = ctx.createRadialGradient(0, 0, 4, 0, 0, this.radius + 8);
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.5, this.color);
        grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(0, 0, this.radius + 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(0, 0, this.radius * 0.85, this.radius * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
}

// ==========================================
// 4. PERSONAGENS (MECÂNICA COMPETITIVA)
// ==========================================
class Fighter {
    constructor({ name, x, y, facing, palette, controls, isCPU = false }) {
        this.name = name;
        this.startX = x;
        this.startY = y; // y representa a base dos pés no chão (492)
        this.x = x;
        this.y = y;
        this.vx = 0;
        this.vy = 0;
        this.width = 56;
        this.height = 148;
        this.facing = facing;
        this.palette = palette;
        this.controls = controls;
        this.isCPU = isCPU;

        this.maxHealth = 100;
        this.health = 100;
        this.maxEnergy = 100;
        this.energy = 0;
        this.score = 0;
        this.roundsWon = 0;

        this.isGrounded = true;
        this.isCrouching = false;
        this.crouchAnim = 0; // Transição suave entre 0 (em pé) e 1 (agachada)
        this.isBlocking = false;
        this.blockFrames = 0;

        // Combate & Cancelamentos
        this.attackType = null;
        this.attackTimer = 0;
        this.attackCooldown = 0;
        this.hasHitThisSwing = false;

        // Estados de dano e combo
        this.hitStun = 0;
        this.knockdownTimer = 0;
        this.invulnTimer = 0;
        this.receivedCombo = 0;

        // Dash (Duplo toque)
        this.dashCooldown = 0;
        this.lastTapDir = null;
        this.lastTapTime = 0;

        // Controle de teclas (anti-spam)
        this.punchHeld = false;
        this.kickHeld = false;
        this.specialHeld = false;
        this.leftHeld = false;
        this.rightHeld = false;

        this.animFrame = 0;
    }

    getCurrentHeight() {
        return (this.isCrouching || this.knockdownTimer > 0) ? 106 : 148;
    }

    getTopY() {
        return this.y - this.getCurrentHeight();
    }

    resetForRound() {
        this.x = this.startX;
        this.y = this.startY;
        this.vx = 0;
        this.vy = 0;
        this.health = this.maxHealth;
        this.energy = Math.floor(this.energy * 0.5);

        this.attackType = null;
        this.attackTimer = 0;
        this.attackCooldown = 0;
        this.hasHitThisSwing = false;
        this.hitStun = 0;
        this.knockdownTimer = 0;
        this.invulnTimer = 0;
        this.receivedCombo = 0;
        this.isBlocking = false;
        this.blockFrames = 0;
        this.isCrouching = false;
        this.crouchAnim = 0;
        this.isGrounded = true;
        this.dashCooldown = 0;
    }

    addEnergy(amount) {
        this.energy = Math.min(this.maxEnergy, Math.max(0, this.energy + amount));
    }

    triggerAttack(type, sfx) {
        if (this.hitStun > 0 || this.knockdownTimer > 0 || this.isBlocking) return;

        const canCancel = this.attackType === 'punch' && this.hasHitThisSwing &&
            (type === 'kick' || type === 'sweep' || type === 'special');

        if (!canCancel && (this.attackTimer > 0 || this.attackCooldown > 0)) return;

        let finalType = type;
        if (type === 'kick') {
            if (!this.isGrounded) finalType = 'air_kick';
            else if (this.isCrouching) finalType = 'sweep';
        }

        if (finalType === 'special') {
            if (this.energy < this.maxEnergy) return;
            this.energy = 0;
            this.attackType = 'special';
            this.attackTimer = 26;
            this.attackCooldown = 20;
            this.hasHitThisSwing = false;
            sfx.play('special');

            const projX = this.facing === 1 ? this.x + this.width + 20 : this.x - 20;
            const projY = this.getTopY() + (this.isCrouching ? 42 : 52);
            gameState.projectiles.push(new SpecialProjectile({
                owner: this,
                x: projX,
                y: projY,
                facing: this.facing,
                color: this.palette.flower
            }));
            criarTextoFlutuante(this.x + this.width / 2, this.getTopY() - 15, 'ONDA TROPICAL!', '#feca57');
            return;
        }

        this.attackType = finalType;
        this.hasHitThisSwing = false;

        if (finalType === 'punch') {
            this.attackTimer = 16;
            this.attackCooldown = 14;
            sfx.play('punch');
        } else if (finalType === 'kick') {
            this.attackTimer = 24;
            this.attackCooldown = 22;
            sfx.play('kick');
        } else if (finalType === 'sweep') {
            this.isCrouching = true;
            this.attackTimer = 28;
            this.attackCooldown = 26;
            sfx.play('sweep');
        } else if (finalType === 'air_kick') {
            this.attackTimer = 22;
            this.attackCooldown = 12;
            sfx.play('kick');
        }
    }

    triggerDash(dir, sfx) {
        if (this.dashCooldown > 0 || this.attackTimer > 0 || this.hitStun > 0 || this.knockdownTimer > 0 || !this.isGrounded) return;
        const isBackdash = dir !== this.facing;
        this.vx = dir * (isBackdash ? 12.5 : 13.5);
        this.dashCooldown = 34;
        if (isBackdash) {
            this.invulnTimer = 10;
        }
        sfx.play('dash');
        criarFaiscas(this.x + this.width / 2, this.y - 4, '#ffffff', 5);
    }

    getAttackBox() {
        if (!this.attackType || this.attackType === 'special') return null;

        let isActive = false;
        let reach = 54;
        let boxHeight = 24;
        let boxY = this.getTopY() + 34;

        if (this.attackType === 'punch') {
            isActive = this.attackTimer <= 12 && this.attackTimer >= 6;
            reach = 56;
            boxHeight = 24;
            boxY = this.getTopY() + (this.isCrouching ? 26 : 34);
        } else if (this.attackType === 'kick') {
            isActive = this.attackTimer <= 17 && this.attackTimer >= 9;
            reach = 74;
            boxHeight = 30;
            boxY = this.getTopY() + 50;
        } else if (this.attackType === 'sweep') {
            isActive = this.attackTimer <= 19 && this.attackTimer >= 10;
            reach = 78;
            boxHeight = 24;
            boxY = this.y - 26; // Rasteira rente ao chão
        } else if (this.attackType === 'air_kick') {
            isActive = this.attackTimer <= 18 && this.attackTimer >= 5;
            reach = 68;
            boxHeight = 34;
            boxY = this.getTopY() + 75;
        }

        if (!isActive) return null;

        return {
            x: this.facing === 1 ? this.x + this.width - 10 : this.x - reach + 10,
            y: boxY,
            width: reach,
            height: boxHeight,
            attackType: this.attackType
        };
    }

    update(keys, opponent, groundY, canvasWidth, sfx) {
        this.animFrame += 0.08;

        if (this.dashCooldown > 0) this.dashCooldown--;
        if (this.invulnTimer > 0) this.invulnTimer--;

        if (this.knockdownTimer > 0) {
            this.knockdownTimer--;
            if (this.knockdownTimer === 0) {
                this.invulnTimer = 18;
                this.receivedCombo = 0;
            }
        }

        if (this.hitStun > 0) {
            this.hitStun--;
            if (this.hitStun === 0 && this.knockdownTimer === 0) {
                this.receivedCombo = 0;
            }
        }

        if (this.isGrounded && this.attackTimer === 0 && this.hitStun === 0 && this.knockdownTimer === 0) {
            this.facing = opponent.x >= this.x ? 1 : -1;
        }

        if (this.attackTimer > 0) {
            this.attackTimer--;
            if (this.attackTimer === 0) {
                this.attackType = null;
            }
        } else if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }

        if (this.hitStun === 0 && this.knockdownTimer === 0) {
            if (this.isCPU) {
                this.runAI(opponent, sfx);
            } else {
                this.handleInput(keys, sfx);
            }
        } else {
            this.isBlocking = false;
            this.blockFrames = 0;
            this.isCrouching = false;
        }

        // Interpolação suave e estável da animação de agachamento
        const targetCrouch = (this.isCrouching && this.isGrounded && this.knockdownTimer === 0) ? 1 : 0;
        this.crouchAnim += (targetCrouch - this.crouchAnim) * 0.35;
        if (Math.abs(targetCrouch - this.crouchAnim) < 0.01) {
            this.crouchAnim = targetCrouch;
        }

        // Física horizontal e atrito
        this.x += this.vx;
        this.vx *= 0.80;

        const overlap = (this.width * 0.75) - Math.abs((this.x + this.width / 2) - (opponent.x + opponent.width / 2));
        if (overlap > 0 && Math.abs(this.y - opponent.y) < 60) {
            this.x += (this.x < opponent.x ? -1 : 1) * (overlap * 0.25);
        }

        if (this.x < 30) this.x = 30;
        if (this.x + this.width > canvasWidth - 30) this.x = canvasWidth - 30 - this.width;

        // Física vertical ancorada na base dos pés (groundY = 492)
        this.y += this.vy;
        if (this.y >= groundY) {
            this.y = groundY;
            this.vy = 0;
            this.isGrounded = true;
            if (this.attackType === 'air_kick') {
                this.attackType = null;
                this.attackTimer = 0;
            }
        } else {
            this.vy += 0.74;
            this.isGrounded = false;
        }
    }

    handleInput(keys, sfx) {
        const c = this.controls;
        const now = performance.now();

        const wantBlock = !!keys[c.block] && this.isGrounded && this.attackTimer === 0;
        if (wantBlock) {
            this.isBlocking = true;
            this.blockFrames++;
        } else {
            this.isBlocking = false;
            this.blockFrames = 0;
        }

        if (this.attackTimer === 0) {
            this.isCrouching = !!keys[c.down] && this.isGrounded;
        } else if (this.attackType === 'sweep') {
            this.isCrouching = true;
        }

        // Detecção de Double-Tap para Dash
        if (keys[c.left]) {
            if (!this.leftHeld) {
                if (this.lastTapDir === -1 && now - this.lastTapTime < 240) {
                    this.triggerDash(-1, sfx);
                    this.lastTapDir = null;
                } else {
                    this.lastTapDir = -1;
                    this.lastTapTime = now;
                }
                this.leftHeld = true;
            }
        } else {
            this.leftHeld = false;
        }

        if (keys[c.right]) {
            if (!this.rightHeld) {
                if (this.lastTapDir === 1 && now - this.lastTapTime < 240) {
                    this.triggerDash(1, sfx);
                    this.lastTapDir = null;
                } else {
                    this.lastTapDir = 1;
                    this.lastTapTime = now;
                }
                this.rightHeld = true;
            }
        } else {
            this.rightHeld = false;
        }

        // Caminhada normal
        if (!this.isBlocking && !this.isCrouching && this.attackTimer === 0 && Math.abs(this.vx) < 4) {
            if (keys[c.left]) this.vx = -3.7;
            if (keys[c.right]) this.vx = 3.7;
        }

        // Pulo
        if (keys[c.up] && this.isGrounded && !this.isBlocking) {
            this.vy = -14.5;
            this.isGrounded = false;
            this.isCrouching = false;
            sfx.play('jump');
        }

        // Golpes
        if (keys[c.punch]) {
            if (!this.punchHeld) {
                this.triggerAttack('punch', sfx);
                this.punchHeld = true;
            }
        } else {
            this.punchHeld = false;
        }

        if (keys[c.kick]) {
            if (!this.kickHeld) {
                this.triggerAttack('kick', sfx);
                this.kickHeld = true;
            }
        } else {
            this.kickHeld = false;
        }

        if (keys[c.special]) {
            if (!this.specialHeld) {
                this.triggerAttack('special', sfx);
                this.specialHeld = true;
            }
        } else {
            this.specialHeld = false;
        }
    }

    runAI(opponent, sfx) {
        const dist = Math.abs(this.x - opponent.x);

        if (this.attackType !== 'sweep') {
            this.isCrouching = false;
        }

        if (this.energy >= this.maxEnergy && dist > 150 && Math.random() < 0.08) {
            this.triggerAttack('special', sfx);
            return;
        }

        if (this.attackType === 'punch' && this.hasHitThisSwing) {
            if (this.energy >= this.maxEnergy) {
                this.triggerAttack('special', sfx);
            } else {
                this.triggerAttack('kick', sfx);
            }
            return;
        }

        const incomingProj = gameState.projectiles.some(p => p.owner !== this && Math.abs(p.x - this.x) < 130);
        if ((opponent.attackTimer > 5 && dist < 125) || incomingProj) {
            if (!this.isBlocking && Math.random() < 0.55) {
                this.isBlocking = true;
                this.blockFrames = 1;
                if (opponent.attackType === 'sweep') this.isCrouching = true;
            } else if (this.isBlocking) {
                this.blockFrames++;
                if (opponent.attackType === 'sweep') this.isCrouching = true;
            }
            return;
        } else {
            this.isBlocking = false;
            this.blockFrames = 0;
        }

        if (this.attackCooldown > 10 && dist < 85 && Math.random() < 0.15) {
            this.triggerDash(-this.facing, sfx);
            return;
        }

        if (dist > 92) {
            this.vx = opponent.x > this.x ? 3.4 : -3.4;
            if (dist > 260 && Math.random() < 0.02) {
                this.triggerDash(this.facing, sfx);
            }
        } else if (this.attackTimer === 0 && this.attackCooldown === 0 && Math.random() < 0.06) {
            const roll = Math.random();
            if (roll < 0.45) {
                this.triggerAttack('punch', sfx);
            } else if (roll < 0.75) {
                this.isCrouching = true;
                this.triggerAttack('kick', sfx);
            } else {
                this.triggerAttack('kick', sfx);
            }
        }
    }

    draw(ctx) {
        ctx.save();
        const isDown = this.knockdownTimer > 0;
        const c = isDown ? 0 : this.crouchAnim;
        const centerX = this.x + this.width / 2;

        // Sombra fixa no chão
        ctx.fillStyle = 'rgba(0, 0, 0, 0.28)';
        ctx.beginPath();
        ctx.ellipse(centerX, 492, isDown ? 52 : (34 + 6 * c), 9, 0, 0, Math.PI * 2);
        ctx.fill();

        if ((this.hitStun > 0 && Math.floor(this.hitStun / 2) % 2 === 0) ||
            (this.invulnTimer > 0 && Math.floor(this.invulnTimer / 2) % 2 === 0)) {
            ctx.filter = 'brightness(1.8) saturate(2)';
        }

        // Origem nos pés da personagem (y = 0 é o chão)
        ctx.translate(centerX, this.y);

        if (isDown) {
            ctx.translate(0, -18);
            ctx.rotate(-this.facing * (Math.PI / 2.1));
            ctx.translate(0, 65);
        }

        ctx.scale(this.facing, 1);

        // Coordenadas locais com y = 0 na sola dos pés (negativo = para cima)
        const footY = -5;
        const hipY = -64 + 26 * c;         // -64 em pé -> -38 agachada
        const torsoLen = 48 - 4 * c;       // 48 em pé -> 44 agachada
        const shoulderY = hipY - torsoLen; // -112 em pé -> -82 agachada
        const headY = shoulderY - 18;      // -130 em pé -> -100 agachada
        const leanX = 5 * c;               // Leve inclinação frontal na guarda baixa
        const bounce = (this.isGrounded && !isDown) ? Math.sin(this.animFrame) * 2.2 * (1 - c) : 0;

        // Cabelo traseiro
        ctx.fillStyle = this.palette.hair;
        ctx.beginPath();
        ctx.moveTo(leanX - 6, headY - 6 + bounce);
        ctx.quadraticCurveTo(-28 - Math.sin(this.animFrame) * 4 * (1 - c), headY + 30, -18 - 5 * c, hipY + 2);
        ctx.lineTo(leanX + 2, hipY - 4);
        ctx.closePath();
        ctx.fill();

        // Pernas articuladas (pés plantados na areia e joelhos dobrando em postura de luta)
        ctx.strokeStyle = this.palette.skin;
        ctx.lineWidth = 10;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        // Perna de trás
        const backFootX = -12 - 4 * c;
        const backKneeX = -9 - 10 * c;
        const backKneeY = (hipY + footY) * 0.52;
        ctx.beginPath();
        ctx.moveTo(-6, hipY);
        ctx.lineTo(backKneeX, backKneeY);
        ctx.lineTo(backFootX, footY);
        ctx.stroke();

        // Perna da frente (ou chute / rasteira / voadora)
        ctx.beginPath();
        ctx.moveTo(8, hipY);
        if (this.attackType === 'kick' && this.attackTimer <= 19 && this.attackTimer >= 7) {
            ctx.lineTo(68, hipY - 16);
        } else if (this.attackType === 'sweep' && this.attackTimer <= 21 && this.attackTimer >= 8) {
            ctx.lineTo(74, footY - 2);
        } else if (this.attackType === 'air_kick') {
            ctx.lineTo(62, hipY + 22);
        } else {
            const frontFootX = 14 + 3 * c;
            const frontKneeX = 11 + 11 * c;
            const frontKneeY = (hipY + footY) * 0.52;
            ctx.lineTo(frontKneeX, frontKneeY);
            ctx.lineTo(frontFootX, footY);
        }
        ctx.stroke();

        // Shorts / Saia
        ctx.fillStyle = this.palette.outfitMain;
        ctx.fillRect(-14, hipY - 10, 28, 20);

        // Tronco
        ctx.fillStyle = this.palette.skin;
        ctx.fillRect(-10 + leanX * 0.5, shoulderY - 2 + bounce, 20, torsoLen + 4);

        // Top
        ctx.fillStyle = this.palette.outfitAccent;
        ctx.fillRect(-12 + leanX * 0.7, shoulderY + bounce, 24, 22);

        // Cabeça
        ctx.fillStyle = this.palette.skin;
        ctx.beginPath();
        ctx.arc(2 + leanX, headY + bounce, 14, 0, Math.PI * 2);
        ctx.fill();

        // Franja / Cabelo topo
        ctx.fillStyle = this.palette.hair;
        ctx.beginPath();
        ctx.arc(leanX, headY - 3 + bounce, 15, Math.PI, Math.PI * 2.15);
        ctx.fill();

        // Flor tropical
        ctx.fillStyle = this.palette.flower;
        ctx.beginPath();
        ctx.arc(-10 + leanX, headY - 8 + bounce, 5, 0, Math.PI * 2);
        ctx.fill();

        // Braços
        ctx.strokeStyle = this.palette.skin;
        ctx.lineWidth = 8;
        ctx.beginPath();
        if (this.isBlocking) {
            ctx.moveTo(6 + leanX, shoulderY + 6 + bounce);
            ctx.lineTo(22 + leanX, shoulderY - 8 + bounce);
            ctx.lineTo(18 + leanX, shoulderY + 20 + bounce);
        } else if ((this.attackType === 'punch' && this.attackTimer <= 13 && this.attackTimer >= 4) || this.attackType === 'special') {
            ctx.moveTo(6 + leanX, shoulderY + 6 + bounce);
            ctx.lineTo(58 + leanX, shoulderY + 2 + bounce);
        } else {
            ctx.moveTo(6 + leanX, shoulderY + 6 + bounce);
            ctx.lineTo(22 + leanX, shoulderY + 16 + bounce);
            ctx.lineTo(26 + leanX, shoulderY + bounce);
        }
        ctx.stroke();

        // Escudo visual de Defesa / Parry
        if (this.isBlocking) {
            const isParryWindow = this.blockFrames <= 8;
            ctx.strokeStyle = isParryWindow ? '#feca57' : '#48dbfb';
            ctx.lineWidth = isParryWindow ? 4.5 : 3;
            ctx.beginPath();
            ctx.arc(22 + leanX, shoulderY + 10, 28, -Math.PI / 2, Math.PI / 2);
            ctx.stroke();
        }

        ctx.restore();
    }
}

// ==========================================
// 5. CENÁRIO PRAIA
// ==========================================
class BeachStage {
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.waveOffset = 0;
    }

    draw(ctx) {
        this.waveOffset += 0.025;

        const skyGrad = ctx.createLinearGradient(0, 0, 0, 340);
        skyGrad.addColorStop(0, '#ff6b6b');
        skyGrad.addColorStop(0.55, '#feca57');
        skyGrad.addColorStop(1, '#ff9ff3');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, this.width, 340);

        ctx.fillStyle = 'rgba(255, 250, 220, 0.85)';
        ctx.beginPath();
        ctx.arc(760, 250, 58, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#576574';
        ctx.beginPath();
        ctx.moveTo(0, 320);
        ctx.lineTo(140, 225);
        ctx.lineTo(310, 290);
        ctx.lineTo(480, 240);
        ctx.lineTo(650, 320);
        ctx.closePath();
        ctx.fill();

        const seaGrad = ctx.createLinearGradient(0, 315, 0, 415);
        seaGrad.addColorStop(0, '#00a8ff');
        seaGrad.addColorStop(1, '#0097e6');
        ctx.fillStyle = seaGrad;
        ctx.fillRect(0, 315, this.width, 100);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        for (let x = 0; x <= this.width; x += 20) {
            const y = 412 + Math.sin(x * 0.02 + this.waveOffset) * 4;
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();

        const sandGrad = ctx.createLinearGradient(0, 410, 0, this.height);
        sandGrad.addColorStop(0, '#f6e58d');
        sandGrad.addColorStop(1, '#e1b12c');
        ctx.fillStyle = sandGrad;
        ctx.fillRect(0, 410, this.width, this.height - 410);

        ctx.fillStyle = '#834c32';
        ctx.fillRect(65, 310, 12, 115);
        ctx.fillRect(185, 310, 12, 115);
        ctx.fillStyle = '#cc8e35';
        ctx.beginPath();
        ctx.moveTo(45, 315);
        ctx.lineTo(130, 265);
        ctx.lineTo(215, 315);
        ctx.closePath();
        ctx.fill();

        ctx.save();
        ctx.translate(915, 375);
        ctx.rotate(0.18);
        ctx.fillStyle = '#ff4757';
        ctx.beginPath();
        ctx.ellipse(0, 0, 14, 52, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-3, -45, 6, 90);
        ctx.restore();
    }
}

// ==========================================
// 6. ESTADO GLOBAL, COMBATE E EFEITOS
// ==========================================
const gameState = {
    canvas: null,
    ctx: null,
    sfx: null,
    stage: null,
    keys: {},
    gameMode: 'pvp',
    status: 'MENU',
    round: 1,
    timer: 60,
    timerInterval: null,
    bannerTimeout: null,
    particles: [],
    floatingTexts: [],
    projectiles: [],
    hitstopFrames: 0,
    shakeFrames: 0,
    loopRunning: false,
    p1: null,
    p2: null
};

function mostrarTela(id) {
    const telas = document.querySelectorAll('.screen');
    for (let i = 0; i < telas.length; i++) {
        telas[i].classList.remove('active');
    }
    const alvo = document.getElementById(id);
    if (alvo) alvo.classList.add('active');
}

function atualizarRecordesMenu() {
    const rec = StorageManager.get();
    const el1 = document.getElementById('rec-p1');
    const el2 = document.getElementById('rec-p2');
    if (el1) el1.textContent = rec.p1Wins;
    if (el2) el2.textContent = rec.p2Wins;
}

function selecionarModo(modo) {
    gameState.gameMode = modo;
    const btnPvp = document.getElementById('mode-pvp');
    const btnCpu = document.getElementById('mode-cpu');
    if (btnPvp) btnPvp.classList.toggle('active', modo === 'pvp');
    if (btnCpu) btnCpu.classList.toggle('active', modo === 'cpu');
}

function iniciarJogo() {
    if (!gameState.canvas) {
        gameState.canvas = document.getElementById('game-canvas');
        gameState.ctx = gameState.canvas.getContext('2d');
        gameState.sfx = new SoundEngine();
        gameState.stage = new BeachStage(gameState.canvas.width, gameState.canvas.height);
    }

    clearInterval(gameState.timerInterval);
    gameState.particles = [];
    gameState.floatingTexts = [];
    gameState.projectiles = [];
    gameState.round = 1;

    gameState.p1 = new Fighter({
        name: 'CARLA',
        x: 240,
        y: 492,
        facing: 1,
        palette: {
            skin: '#ffdbac',
            hair: '#ff9ff3',
            outfitMain: '#00d2d3',
            outfitAccent: '#ffffff',
            flower: '#ff6b6b'
        },
        controls: {
            up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD',
            punch: 'KeyF', kick: 'KeyG', block: 'KeyH', special: 'KeyR'
        }
    });

    gameState.p2 = new Fighter({
        name: 'BELINHA',
        x: 720,
        y: 492,
        facing: -1,
        isCPU: gameState.gameMode === 'cpu',
        palette: {
            skin: '#f1c27d',
            hair: '#222f3e',
            outfitMain: '#ff4757',
            outfitAccent: '#feca57',
            flower: '#48dbfb'
        },
        controls: {
            up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight',
            punch: 'KeyJ', kick: 'KeyK', block: 'KeyL', special: 'KeyP'
        }
    });

    mostrarTela('gameplay-screen');
    atualizarHUD();
    iniciarRound();

    if (!gameState.loopRunning) {
        gameState.loopRunning = true;
        requestAnimationFrame(loopPrincipal);
    }
}

function voltarMenu() {
    clearInterval(gameState.timerInterval);
    gameState.status = 'MENU';
    atualizarRecordesMenu();
    mostrarTela('start-screen');
}

function iniciarRound() {
    gameState.status = 'INTRO';
    gameState.timer = 60;
    gameState.particles = [];
    gameState.floatingTexts = [];
    gameState.projectiles = [];
    document.getElementById('timer').textContent = gameState.timer;
    gameState.p1.resetForRound();
    gameState.p2.resetForRound();
    atualizarHUD();

    document.getElementById('round-display').textContent = 'ROUND ' + gameState.round;
    exibirAviso('ROUND ' + gameState.round);
    gameState.sfx.play('start');

    setTimeout(() => {
        if (gameState.status !== 'INTRO') return;
        exibirAviso('FIGHT!');
        gameState.status = 'FIGHTING';
        iniciarCronometro();
    }, 1200);
}

function exibirAviso(texto) {
    const banner = document.getElementById('announcement-banner');
    banner.textContent = texto;
    banner.classList.remove('hidden');
    clearTimeout(gameState.bannerTimeout);
    gameState.bannerTimeout = setTimeout(() => banner.classList.add('hidden'), 950);
}

function iniciarCronometro() {
    clearInterval(gameState.timerInterval);
    gameState.timerInterval = setInterval(() => {
        if (gameState.status !== 'FIGHTING') return;
        gameState.timer--;
        document.getElementById('timer').textContent = gameState.timer;
        if (gameState.timer <= 0) {
            if (gameState.p1.health >= gameState.p2.health) finalizarRound(gameState.p1);
            else finalizarRound(gameState.p2);
        }
    }, 1000);
}

function verificarGolpes() {
    processarImpactoFisico(gameState.p1, gameState.p2);
    processarImpactoFisico(gameState.p2, gameState.p1);
    processarProjeteis();
}

function processarImpactoFisico(atacante, defensor) {
    if (atacante.hasHitThisSwing) return;
    if (defensor.invulnTimer > 0 || defensor.knockdownTimer > 0) return;

    const hitbox = atacante.getAttackBox();
    if (!hitbox) return;

    const defTopY = defensor.getTopY();
    const defH = defensor.getCurrentHeight();
    const acertou =
        hitbox.x < defensor.x + defensor.width &&
        hitbox.x + hitbox.width > defensor.x &&
        hitbox.y < defTopY + defH &&
        hitbox.y + hitbox.height > defTopY;

    if (acertou) {
        atacante.hasHitThisSwing = true;
        resolverDanoOuDefesa(atacante, defensor, hitbox.attackType, hitbox.x + hitbox.width / 2, hitbox.y + hitbox.height / 2);
    }
}

function processarProjeteis() {
    for (let i = gameState.projectiles.length - 1; i >= 0; i--) {
        const proj = gameState.projectiles[i];
        proj.update(gameState.canvas.width);

        if (!proj.active) {
            gameState.projectiles.splice(i, 1);
            continue;
        }

        const defensor = proj.owner === gameState.p1 ? gameState.p2 : gameState.p1;
        if (defensor.invulnTimer > 0 || defensor.knockdownTimer > 0) continue;

        const hitbox = proj.getHitbox();
        const defTopY = defensor.getTopY();
        const defH = defensor.getCurrentHeight();
        const acertou =
            hitbox.x < defensor.x + defensor.width &&
            hitbox.x + hitbox.width > defensor.x &&
            hitbox.y < defTopY + defH &&
            hitbox.y + hitbox.height > defTopY;

        if (acertou) {
            proj.active = false;
            gameState.projectiles.splice(i, 1);
            resolverDanoOuDefesa(proj.owner, defensor, 'special', proj.x, proj.y);
        }
    }
}

function resolverDanoOuDefesa(atacante, defensor, tipoAtaque, impactX, impactY) {
    let guardaValida = defensor.isBlocking;
    if (guardaValida) {
        if (tipoAtaque === 'sweep' && !defensor.isCrouching) guardaValida = false;
        if (tipoAtaque === 'air_kick' && defensor.isCrouching) guardaValida = false;
    }

    const defTopY = defensor.getTopY();
    const atkTopY = atacante.getTopY();

    if (guardaValida) {
        if (defensor.blockFrames <= 8) {
            gameState.sfx.play('parry');
            gameState.hitstopFrames = 7;
            atacante.hitStun = 22;
            atacante.vx = -atacante.facing * 8;
            defensor.addEnergy(25);
            defensor.score += 150;
            criarFaiscas(impactX, impactY, '#feca57', 16);
            criarTextoFlutuante(defensor.x + defensor.width / 2, defTopY - 10, 'PARRY!', '#feca57');
        } else {
            gameState.sfx.play('block');
            const chipDmg = tipoAtaque === 'special' ? 4 : 2;
            defensor.health = Math.max(1, defensor.health - chipDmg);
            atacante.vx = -atacante.facing * 7;
            defensor.vx = atacante.facing * 5;
            defensor.addEnergy(8);
            atacante.addEnergy(5);
            defensor.score += 50;
            criarFaiscas(impactX, impactY, '#48dbfb', 10);
            criarTextoFlutuante(defensor.x + defensor.width / 2, defTopY - 10, 'GUARD', '#48dbfb');
        }
    } else {
        const isCounter = defensor.attackTimer > 0;
        const counterMult = isCounter ? 1.25 : 1.0;

        let baseDmg = 7;
        let hitStun = 14;
        let pushback = 9.5;
        let isKnockdown = false;

        if (tipoAtaque === 'punch') {
            baseDmg = 7;
            hitStun = 16;
            pushback = 6.5;
        } else if (tipoAtaque === 'kick') {
            baseDmg = 12;
            hitStun = 14;
            pushback = 12.5;
        } else if (tipoAtaque === 'sweep') {
            baseDmg = 11;
            hitStun = 12;
            pushback = 8;
            isKnockdown = true;
        } else if (tipoAtaque === 'air_kick') {
            baseDmg = 11;
            hitStun = 15;
            pushback = 9;
        } else if (tipoAtaque === 'special') {
            baseDmg = 24;
            hitStun = 20;
            pushback = 16;
            isKnockdown = true;
            gameState.shakeFrames = 10;
        }

        const finalDmg = Math.round(baseDmg * counterMult);
        defensor.health = Math.max(0, defensor.health - finalDmg);
        defensor.attackType = null;
        defensor.attackTimer = 0;

        defensor.receivedCombo++;
        if (defensor.receivedCombo >= 2) {
            criarTextoFlutuante(
                atacante.x + atacante.width / 2,
                atkTopY - 25,
                `${defensor.receivedCombo} HIT COMBO!`,
                '#ff9ff3'
            );
            atacante.score += defensor.receivedCombo * 40;
        } else if (isCounter) {
            criarTextoFlutuante(defensor.x + defensor.width / 2, defTopY - 15, 'COUNTER!', '#ff6b6b');
        } else if (tipoAtaque === 'sweep') {
            criarTextoFlutuante(defensor.x + defensor.width / 2, defTopY - 15, 'RASTEIRA!', '#1dd1a1');
        }

        if (isKnockdown) {
            defensor.knockdownTimer = 36;
            defensor.vy = -6;
        } else {
            defensor.hitStun = hitStun;
        }

        defensor.vx = atacante.facing * pushback;
        atacante.vx = -atacante.facing * 2;

        if (tipoAtaque !== 'special') {
            atacante.addEnergy(finalDmg * 1.4);
        }
        defensor.addEnergy(finalDmg * 0.9);
        atacante.score += finalDmg * 10;

        gameState.hitstopFrames = tipoAtaque === 'special' ? 6 : 3;
        criarFaiscas(impactX, impactY, isCounter ? '#ff6b6b' : '#feca57', 12);
    }

    atualizarHUD();

    if (defensor.health <= 0) {
        finalizarRound(atacante);
    }
}

function criarFaiscas(x, y, color, count = 10) {
    for (let i = 0; i < count; i++) {
        gameState.particles.push({
            x, y,
            vx: (Math.random() - 0.5) * 11,
            vy: (Math.random() - 0.5) * 11,
            life: 16,
            color
        });
    }
}

function criarTextoFlutuante(x, y, text, color) {
    gameState.floatingTexts.push({
        x, y, text, color, life: 38
    });
}

function atualizarHUD() {
    const { p1, p2 } = gameState;
    if (!p1 || !p2) return;

    const p1Pct = (p1.health / p1.maxHealth) * 100;
    const p2Pct = (p2.health / p2.maxHealth) * 100;

    const bar1 = document.getElementById('p1-health');
    const bar2 = document.getElementById('p2-health');

    bar1.style.width = p1Pct + '%';
    bar2.style.width = p2Pct + '%';

    bar1.style.background = p1Pct <= 30
        ? 'linear-gradient(90deg, #ff4757, #ff6b81)'
        : 'linear-gradient(90deg, #1dd1a1, #10ac84)';

    bar2.style.background = p2Pct <= 30
        ? 'linear-gradient(90deg, #ff4757, #ff6b81)'
        : 'linear-gradient(90deg, #1dd1a1, #10ac84)';

    const e1Pct = (p1.energy / p1.maxEnergy) * 100;
    const e2Pct = (p2.energy / p2.maxEnergy) * 100;
    const eBar1 = document.getElementById('p1-energy');
    const eBar2 = document.getElementById('p2-energy');
    const eTag1 = document.getElementById('p1-special-tag');
    const eTag2 = document.getElementById('p2-special-tag');

    eBar1.style.width = e1Pct + '%';
    eBar2.style.width = e2Pct + '%';

    eBar1.classList.toggle('ready', p1.energy >= p1.maxEnergy);
    eTag1.classList.toggle('ready', p1.energy >= p1.maxEnergy);

    eBar2.classList.toggle('ready', p2.energy >= p2.maxEnergy);
    eTag2.classList.toggle('ready', p2.energy >= p2.maxEnergy);

    document.getElementById('p1-score').textContent = p1.score;
    document.getElementById('p2-score').textContent = p2.score;

    const p1Dots = document.querySelectorAll('#p1-rounds .dot');
    p1Dots.forEach((dot, idx) => dot.classList.toggle('won', idx < p1.roundsWon));

    const p2Dots = document.querySelectorAll('#p2-rounds .dot');
    p2Dots.forEach((dot, idx) => dot.classList.toggle('won', idx < p2.roundsWon));
}

function finalizarRound(vencedor) {
    if (gameState.status !== 'FIGHTING') return;
    gameState.status = 'ROUND_END';
    clearInterval(gameState.timerInterval);
    gameState.sfx.play('ko');
    gameState.shakeFrames = 14;

    vencedor.roundsWon++;
    vencedor.score += 500;
    atualizarHUD();
    exibirAviso('K.O.!');

    setTimeout(() => {
        if (vencedor.roundsWon >= 2) {
            encerrarPartida(vencedor);
        } else {
            gameState.round++;
            iniciarRound();
        }
    }, 1800);
}

function encerrarPartida(vencedor) {
    gameState.status = 'GAME_OVER';
    const pNum = vencedor === gameState.p1 ? 1 : 2;
    const perdedor = pNum === 1 ? gameState.p2 : gameState.p1;
    const history = StorageManager.addWin(pNum);
    atualizarRecordesMenu();

    document.getElementById('winner-title').textContent = 'VITÓRIA DE ' + vencedor.name + '!';
    document.getElementById('winner-subtitle').textContent =
        `${vencedor.name} venceu a partida por ${vencedor.roundsWon} a ${perdedor.roundsWon}`;

    document.getElementById('final-p1-score').textContent = gameState.p1.score;
    document.getElementById('final-p2-score').textContent = gameState.p2.score;
    document.getElementById('total-history').textContent = `${history.p1Wins} - ${history.p2Wins}`;

    mostrarTela('gameover-screen');
}

// ==========================================
// 7. LOOP PRINCIPAL E CONTROLES DE TECLADO
// ==========================================
function loopPrincipal() {
    const { ctx, canvas, stage, p1, p2, particles, floatingTexts, projectiles, status, keys, sfx } = gameState;
    const groundY = 492;

    if (ctx && stage && p1 && p2) {
        if (gameState.hitstopFrames > 0) {
            gameState.hitstopFrames--;
            requestAnimationFrame(loopPrincipal);
            return;
        }

        ctx.save();

        if (gameState.shakeFrames > 0) {
            gameState.shakeFrames--;
            const dx = (Math.random() - 0.5) * 10;
            const dy = (Math.random() - 0.5) * 10;
            ctx.translate(dx, dy);
        }

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        stage.draw(ctx);

        if (status === 'FIGHTING') {
            p1.update(keys, p2, groundY, canvas.width, sfx);
            p2.update(keys, p1, groundY, canvas.width, sfx);
            verificarGolpes();
        }

        p1.draw(ctx);
        p2.draw(ctx);

        for (let i = 0; i < projectiles.length; i++) {
            projectiles[i].draw(ctx);
        }

        for (let i = particles.length - 1; i >= 0; i--) {
            const pt = particles[i];
            pt.x += pt.vx;
            pt.y += pt.vy;
            pt.life--;

            ctx.save();
            ctx.globalAlpha = Math.max(0, pt.life / 16);
            ctx.fillStyle = pt.color;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();

            if (pt.life <= 0) {
                particles.splice(i, 1);
            }
        }

        for (let i = floatingTexts.length - 1; i >= 0; i--) {
            const ft = floatingTexts[i];
            ft.y -= 0.9;
            ft.life--;

            ctx.save();
            ctx.globalAlpha = Math.min(1, ft.life / 15);
            ctx.font = '900 18px "Segoe UI", sans-serif';
            ctx.textAlign = 'center';
            ctx.lineWidth = 4;
            ctx.strokeStyle = '#000000';
            ctx.strokeText(ft.text, ft.x, ft.y);
            ctx.fillStyle = ft.color;
            ctx.fillText(ft.text, ft.x, ft.y);
            ctx.restore();

            if (ft.life <= 0) {
                floatingTexts.splice(i, 1);
            }
        }

        ctx.restore();
    }

    requestAnimationFrame(loopPrincipal);
}

window.addEventListener('keydown', (e) => {
    gameState.keys[e.code] = true;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
    }
});

window.addEventListener('keyup', (e) => {
    gameState.keys[e.code] = false;
});

window.addEventListener('DOMContentLoaded', () => {
    atualizarRecordesMenu();
});