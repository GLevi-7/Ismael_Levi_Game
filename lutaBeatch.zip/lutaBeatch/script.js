/**
 * KENTING SUNSET: BEACH STRIKERS
 * Engine 100% Vanilla JS + HTML5 Canvas + Audio()
 */

// ==========================================
// 1. MOTOR DE ÁUDIO USANDO Audio()
// ==========================================
class SoundEngine {
    constructor() {
        this.sounds = {};
        try {
            this.sounds = {
                punch: this.createSound(180, 0.12, 'sawtooth', 80),
                kick: this.createSound(130, 0.18, 'square', 45),
                block: this.createSound(620, 0.10, 'triangle', 900),
                jump: this.createSound(260, 0.15, 'sine', 520),
                ko: this.createSound(110, 0.55, 'sawtooth', 30),
                start: this.createSound(440, 0.25, 'triangle', 660)
            };
        } catch (e) {}
    }

    createSound(startFreq, duration, type, endFreq) {
        const sampleRate = 22050;
        const numSamples = Math.floor(sampleRate * duration);
        const buffer = new ArrayBuffer(44 + numSamples * 2);
        const view = new DataView(buffer);

        const writeString = (offset, str) => {
            for (let i = 0; i < str.length; i++) {
                view.setUint8(offset + i, str.charCodeAt(i));
            }
        };

        writeString(0, 'RIFF');
        view.setUint32(4, 36 + numSamples * 2, true);
        writeString(8, 'WAVE');
        writeString(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        writeString(36, 'data');
        view.setUint32(40, numSamples * 2, true);

        let phase = 0;
        for (let i = 0; i < numSamples; i++) {
            const t = i / numSamples;
            const freq = startFreq + (endFreq - startFreq) * t;
            const envelope = Math.pow(1 - t, 1.5);
            phase += (2 * Math.PI * freq) / sampleRate;

            let sample = 0;
            if (type === 'sine') sample = Math.sin(phase);
            else if (type === 'square') sample = Math.sin(phase) >= 0 ? 1 : -1;
            else if (type === 'sawtooth') sample = 2 * ((phase / (2 * Math.PI)) % 1) - 1;
            else if (type === 'triangle') sample = Math.asin(Math.sin(phase)) * (2 / Math.PI);

            const val = Math.max(-1, Math.min(1, sample * envelope * 0.45));
            view.setInt16(44 + i * 2, val * 32767, true);
        }

        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return new Audio('data:audio/wav;base64,' + btoa(binary));
    }

    play(name) {
        const sfx = this.sounds[name];
        if (!sfx) return;
        try {
            const clone = sfx.cloneNode();
            clone.volume = 0.6;
            clone.play().catch(() => {});
        } catch (e) {}
    }
}

// ==========================================
// 2. LOCALSTORAGE (RECORDS)
// ==========================================
const StorageManager = {
    KEY: 'kenting_sunset_records_v1',
    get() {
        try {
            const raw = localStorage.getItem(this.KEY);
            return raw ? JSON.parse(raw) : { p1Wins: 0, p2Wins: 0 };
        } catch (e) {
            return { p1Wins: 0, p2Wins: 0 };
        }
    },
    addWin(playerNum) {
        const data = this.get();
        if (playerNum === 1) data.p1Wins++;
        else data.p2Wins++;
        try {
            localStorage.setItem(this.KEY, JSON.stringify(data));
        } catch (e) {}
        return data;
    }
};

// ==========================================
// 3. PERSONAGENS
// ==========================================
class Fighter {
    constructor({ name, x, y, facing, palette, controls, isCPU = false }) {
        this.name = name;
        this.startX = x;
        this.startY = y;
        this.x = x;
        this.y = y;
        this.vx = 0;
        this.vy = 0;
        this.width = 56;
        this.height = 148;
        this.facing = facing;
        this.palette = palette;
        this.controls = controls;
        this.isCPU = isCPU;

        this.maxHealth = 100;
        this.health = 100;
        this.score = 0;
        this.roundsWon = 0;

        this.isGrounded = false;
        this.isCrouching = false;
        this.isBlocking = false;
        this.attackType = null;
        this.attackTimer = 0;
        this.hasHitThisSwing = false;
        this.hitStun = 0;
        this.animFrame = 0;
    }

    resetForRound() {
        this.x = this.startX;
        this.y = this.startY;
        this.vx = 0;
        this.vy = 0;
        this.health = this.maxHealth;
        this.attackType = null;
        this.attackTimer = 0;
        this.hitStun = 0;
        this.isBlocking = false;
        this.isCrouching = false;
    }

    triggerAttack(type, sfx) {
        if (this.attackTimer > 0 || this.hitStun > 0 || this.isBlocking) return;
        this.attackType = type;
        this.attackTimer = type === 'punch' ? 14 : 20;
        this.hasHitThisSwing = false;
        sfx.play(type);
    }

    getAttackBox() {
        if (!this.attackType || this.attackTimer <= 4) return null;
        const reach = this.attackType === 'punch' ? 58 : 74;
        const boxHeight = this.attackType === 'punch' ? 26 : 34;
        const offsetY = this.attackType === 'punch' ? 35 : 52;

        return {
            x: this.facing === 1 ? this.x + this.width - 10 : this.x - reach + 10,
            y: this.y + offsetY,
            width: reach,
            height: boxHeight
        };
    }

    update(keys, opponent, groundY, canvasWidth, sfx) {
        this.animFrame += 0.15;

        if (this.isGrounded && this.attackTimer === 0 && this.hitStun === 0) {
            this.facing = opponent.x >= this.x ? 1 : -1;
        }

        if (this.hitStun > 0) this.hitStun--;
        if (this.attackTimer > 0) {
            this.attackTimer--;
            if (this.attackTimer === 0) this.attackType = null;
        }

        if (this.hitStun === 0) {
            if (this.isCPU) {
                this.runAI(opponent, sfx);
            } else {
                this.handleInput(keys, sfx);
            }
        }

        this.x += this.vx;
        this.vx *= 0.78;

        if (this.x < 30) this.x = 30;
        if (this.x + this.width > canvasWidth - 30) this.x = canvasWidth - 30 - this.width;

        this.y += this.vy;
        const currentHeight = this.isCrouching ? 105 : 148;
        if (this.y + currentHeight >= groundY) {
            this.y = groundY - currentHeight;
            this.vy = 0;
            this.isGrounded = true;
        } else {
            this.vy += 0.85;
            this.isGrounded = false;
        }
    }

    handleInput(keys, sfx) {
        const c = this.controls;
        this.isBlocking = !!keys[c.block] && this.isGrounded && this.attackTimer === 0;
        this.isCrouching = !!keys[c.down] && this.isGrounded && !this.isBlocking;

        if (!this.isBlocking && !this.isCrouching && this.attackTimer === 0) {
            if (keys[c.left]) this.vx = -6.2;
            if (keys[c.right]) this.vx = 6.2;
        }

        if (keys[c.up] && this.isGrounded && !this.isBlocking) {
            this.vy = -16.5;
            this.isGrounded = false;
            sfx.play('jump');
        }

        if (keys[c.punch]) this.triggerAttack('punch', sfx);
        if (keys[c.kick]) this.triggerAttack('kick', sfx);
    }

    runAI(opponent, sfx) {
        const dist = Math.abs(this.x - opponent.x);
        this.isBlocking = false;
        this.isCrouching = false;

        if (opponent.attackTimer > 6 && dist < 135 && Math.random() < 0.45) {
            this.isBlocking = true;
            return;
        }

        if (dist > 95) {
            this.vx = opponent.x > this.x ? 5.2 : -5.2;
        } else if (this.attackTimer === 0 && Math.random() < 0.08) {
            this.triggerAttack(Math.random() < 0.55 ? 'punch' : 'kick', sfx);
        }
    }

    draw(ctx) {
        ctx.save();
        const currentH = this.isCrouching ? 105 : 148;
        const centerX = this.x + this.width / 2;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.28)';
        ctx.beginPath();
        ctx.ellipse(centerX, 492, 34, 9, 0, 0, Math.PI * 2);
        ctx.fill();

        if (this.hitStun > 0 && Math.floor(this.hitStun / 2) % 2 === 0) {
            ctx.filter = 'brightness(1.8) saturate(2)';
        }

        ctx.translate(centerX, this.y);
        ctx.scale(this.facing, 1);

        const bounce = this.isGrounded ? Math.sin(this.animFrame) * 2.5 : 0;

        ctx.fillStyle = this.palette.hair;
        ctx.beginPath();
        ctx.moveTo(-6, 12 + bounce);
        ctx.quadraticCurveTo(-28 - Math.sin(this.animFrame) * 5, 45, -18, 92);
        ctx.lineTo(4, 85);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = this.palette.skin;
        ctx.lineWidth = 10;
        ctx.lineCap = 'round';

        ctx.beginPath();
        ctx.moveTo(-6, currentH - 58);
        ctx.lineTo(-12, currentH - 6);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(8, currentH - 58);
        if (this.attackType === 'kick' && this.attackTimer > 3) {
            ctx.lineTo(68, currentH - 72);
        } else {
            ctx.lineTo(14, currentH - 6);
        }
        ctx.stroke();

        ctx.fillStyle = this.palette.outfitMain;
        ctx.fillRect(-14, currentH - 70, 28, 22);

        ctx.fillStyle = this.palette.skin;
        ctx.fillRect(-10, 34 + bounce, 20, currentH - 100);

        ctx.fillStyle = this.palette.outfitAccent;
        ctx.fillRect(-12, 36 + bounce, 24, 24);

        ctx.fillStyle = this.palette.skin;
        ctx.beginPath();
        ctx.arc(2, 18 + bounce, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = this.palette.hair;
        ctx.beginPath();
        ctx.arc(0, 15 + bounce, 15, Math.PI, Math.PI * 2.15);
        ctx.fill();

        ctx.fillStyle = this.palette.flower;
        ctx.beginPath();
        ctx.arc(-10, 10 + bounce, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = this.palette.skin;
        ctx.lineWidth = 8;
        ctx.beginPath();
        if (this.isBlocking) {
            ctx.moveTo(6, 42 + bounce);
            ctx.lineTo(22, 26 + bounce);
            ctx.lineTo(18, 56 + bounce);
        } else if (this.attackType === 'punch' && this.attackTimer > 3) {
            ctx.moveTo(6, 42 + bounce);
            ctx.lineTo(58, 38 + bounce);
        } else {
            ctx.moveTo(6, 42 + bounce);
            ctx.lineTo(22, 52 + bounce);
            ctx.lineTo(26, 36 + bounce);
        }
        ctx.stroke();

        if (this.isBlocking) {
            ctx.strokeStyle = '#48dbfb';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(22, 45, 28, -Math.PI / 2, Math.PI / 2);
            ctx.stroke();
        }

        ctx.restore();
    }
}

// ==========================================
// 4. CENÁRIO PRAIA DE TAIWAN
// ==========================================
class BeachStage {
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.waveOffset = 0;
    }

    draw(ctx) {
        this.waveOffset += 0.03;

        const skyGrad = ctx.createLinearGradient(0, 0, 0, 340);
        skyGrad.addColorStop(0, '#ff6b6b');
        skyGrad.addColorStop(0.55, '#feca57');
        skyGrad.addColorStop(1, '#ff9ff3');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, this.width, 340);

        ctx.fillStyle = 'rgba(255, 250, 220, 0.85)';
        ctx.beginPath();
        ctx.arc(760, 250, 58, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#576574';
        ctx.beginPath();
        ctx.moveTo(0, 320);
        ctx.lineTo(140, 225);
        ctx.lineTo(310, 290);
        ctx.lineTo(480, 240);
        ctx.lineTo(650, 320);
        ctx.closePath();
        ctx.fill();

        const seaGrad = ctx.createLinearGradient(0, 315, 0, 415);
        seaGrad.addColorStop(0, '#00a8ff');
        seaGrad.addColorStop(1, '#0097e6');
        ctx.fillStyle = seaGrad;
        ctx.fillRect(0, 315, this.width, 100);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        for (let x = 0; x <= this.width; x += 20) {
            const y = 412 + Math.sin(x * 0.02 + this.waveOffset) * 4;
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();

        const sandGrad = ctx.createLinearGradient(0, 410, 0, this.height);
        sandGrad.addColorStop(0, '#f6e58d');
        sandGrad.addColorStop(1, '#e1b12c');
        ctx.fillStyle = sandGrad;
        ctx.fillRect(0, 410, this.width, this.height - 410);

        ctx.fillStyle = '#834c32';
        ctx.fillRect(65, 310, 12, 115);
        ctx.fillRect(185, 310, 12, 115);
        ctx.fillStyle = '#cc8e35';
        ctx.beginPath();
        ctx.moveTo(45, 315);
        ctx.lineTo(130, 265);
        ctx.lineTo(215, 315);
        ctx.closePath();
        ctx.fill();

        ctx.save();
        ctx.translate(915, 375);
        ctx.rotate(0.18);
        ctx.fillStyle = '#ff4757';
        ctx.beginPath();
        ctx.ellipse(0, 0, 14, 52, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-3, -45, 6, 90);
        ctx.restore();
    }
}

// ==========================================
// 5. ESTADO GLOBAL E FUNÇÕES DOS BOTÕES
// ==========================================
const gameState = {
    canvas: null,
    ctx: null,
    sfx: null,
    stage: null,
    keys: {},
    gameMode: 'pvp',
    status: 'MENU',
    round: 1,
    timer: 60,
    timerInterval: null,
    bannerTimeout: null,
    particles: [],
    loopRunning: false,
    p1: null,
    p2: null
};

function mostrarTela(id) {
    const telas = document.querySelectorAll('.screen');
    for (let i = 0; i < telas.length; i++) {
        telas[i].classList.remove('active');
    }
    const alvo = document.getElementById(id);
    if (alvo) alvo.classList.add('active');
}

function atualizarRecordesMenu() {
    const rec = StorageManager.get();
    const el1 = document.getElementById('rec-p1');
    const el2 = document.getElementById('rec-p2');
    if (el1) el1.textContent = rec.p1Wins;
    if (el2) el2.textContent = rec.p2Wins;
}

// Função chamada diretamente pelo onclick dos botões de modo
function selecionarModo(modo) {
    gameState.gameMode = modo;
    const btnPvp = document.getElementById('mode-pvp');
    const btnCpu = document.getElementById('mode-cpu');
    if (btnPvp) btnPvp.classList.toggle('active', modo === 'pvp');
    if (btnCpu) btnCpu.classList.toggle('active', modo === 'cpu');
}

// Função chamada diretamente pelo onclick de INICIAR COMBATE e JOGAR NOVAMENTE
function iniciarJogo() {
    if (!gameState.canvas) {
        gameState.canvas = document.getElementById('game-canvas');
        gameState.ctx = gameState.canvas.getContext('2d');
        gameState.sfx = new SoundEngine();
        gameState.stage = new BeachStage(gameState.canvas.width, gameState.canvas.height);
    }

    gameState.round = 1;
    gameState.p1 = new Fighter({
        name: 'SORA',
        x: 240,
        y: 344,
        facing: 1,
        palette: {
            skin: '#ffdbac',
            hair: '#ff9ff3',
            outfitMain: '#00d2d3',
            outfitAccent: '#ffffff',
            flower: '#ff6b6b'
        },
        controls: { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD', punch: 'KeyF', kick: 'KeyG', block: 'KeyH' }
    });

    gameState.p2 = new Fighter({
        name: 'MEI',
        x: 720,
        y: 344,
        facing: -1,
        isCPU: gameState.gameMode === 'cpu',
        palette: {
            skin: '#f1c27d',
            hair: '#222f3e',
            outfitMain: '#ff4757',
            outfitAccent: '#feca57',
            flower: '#48dbfb'
        },
        controls: { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', punch: 'KeyJ', kick: 'KeyK', block: 'KeyL' }
    });

    mostrarTela('gameplay-screen');
    atualizarHUD();
    iniciarRound();

    if (!gameState.loopRunning) {
        gameState.loopRunning = true;
        requestAnimationFrame(loopPrincipal);
    }
}

// Função chamada diretamente pelo onclick de MENU INICIAL
function voltarMenu() {
    clearInterval(gameState.timerInterval);
    gameState.status = 'MENU';
    atualizarRecordesMenu();
    mostrarTela('start-screen');
}

function iniciarRound() {
    gameState.status = 'INTRO';
    gameState.timer = 60;
    document.getElementById('timer').textContent = gameState.timer;
    gameState.p1.resetForRound();
    gameState.p2.resetForRound();
    atualizarHUD();

    document.getElementById('round-display').textContent = 'ROUND ' + gameState.round;
    exibirAviso('ROUND ' + gameState.round);
    gameState.sfx.play('start');

    setTimeout(() => {
        exibirAviso('FIGHT!');
        gameState.status = 'FIGHTING';
        iniciarCronometro();
    }, 1200);
}

function exibirAviso(texto) {
    const banner = document.getElementById('announcement-banner');
    banner.textContent = texto;
    banner.classList.remove('hidden');
    clearTimeout(gameState.bannerTimeout);
    gameState.bannerTimeout = setTimeout(() => banner.classList.add('hidden'), 950);
}

function iniciarCronometro() {
    clearInterval(gameState.timerInterval);
    gameState.timerInterval = setInterval(() => {
        if (gameState.status !== 'FIGHTING') return;
        gameState.timer--;
        document.getElementById('timer').textContent = gameState.timer;
        if (gameState.timer <= 0) {
            if (gameState.p1.health >= gameState.p2.health) finalizarRound(gameState.p1);
            else finalizarRound(gameState.p2);
        }
    }, 1000);
}

function verificarGolpes() {
    processarImpacto(gameState.p1, gameState.p2);
    processarImpacto(gameState.p2, gameState.p1);
}

function processarImpacto(atacante, defensor) {
    if (atacante.hasHitThisSwing) return;
    const hitbox = atacante.getAttackBox();
    if (!hitbox) return;

    const defH = defensor.isCrouching ? 105 : 148;
    const acertou =
        hitbox.x < defensor.x + defensor.width &&
        hitbox.x + hitbox.width > defensor.x &&
        hitbox.y < defensor.y + defH &&
        hitbox.y + hitbox.height > defensor.y;

    if (acertou) {
        atacante.hasHitThisSwing = true;
        const impactX = defensor.x + defensor.width / 2;
        const impactY = hitbox.y + hitbox.height / 2;

        if (defensor.isBlocking) {
            gameState.sfx.play('block');
            atacante.vx = -atacante.facing * 9;
            defensor.score += 50;
            criarFaiscas(impactX, impactY, '#48dbfb');
        } else {
            const dmg = atacante.attackType === 'punch' ? 9 : 14;
            defensor.health = Math.max(0, defensor.health - dmg);
            defensor.hitStun = 12;
            defensor.vx = atacante.facing * 7.5;
            atacante.score += dmg * 10;
            criarFaiscas(impactX, impactY, '#feca57');
        }

        atualizarHUD();

        if (defensor.health <= 0) {
            finalizarRound(atacante);
        }
    }
}

function criarFaiscas(x, y, color) {
    for (let i = 0; i < 10; i++) {
        gameState.particles.push({
            x, y,
            vx: (Math.random() - 0.5) * 10,
            vy: (Math.random() - 0.5) * 10,
            life: 16,
            color
        });
    }
}

function finalizarRound(vencedor) {
    if (gameState.status !== 'FIGHTING') return;
    gameState.status = 'ROUND_END';
    clearInterval(gameState.timerInterval);
    gameState.sfx.play('ko');

    vencedor.roundsWon++;
    vencedor.score += 500;
    atualizarHUD();
    exibirAviso('K.O.!');

    setTimeout(() => {
        if (vencedor.roundsWon >= 2) {
            encerrarPartida(vencedor);
        } else {
            gameState.round++;
            iniciarRound();
        }
    }, 1800);
}

function encerrarPartida(vencedor) {
    gameState.status = 'GAME_OVER';
    const pNum = vencedor === gameState.p1 ? 1 : 2;
    const history = StorageManager.addWin(pNum);
    atualizarRecordesMenu();

    document.getElementById('winner-title').textContent = vencedor.name + ' VENCEU!';
    document.getElementById('winner-subtitle').textContent =
        pNum === 1 ? 'Vitória do Jogador 1 na arena tropical!' :
        (gameState.gameMode === 'cpu' ? 'A CPU dominou a praia!' : 'Vitória do Jogador 2 na arena tropical!');

    document.getElementById('final-p1-score').textContent = gameState.p1.score;
    document.getElementById('final-p2-score').textContent = gameState.p2.score;
    document.getElementById('total-history').textContent = history.p1Wins + ' (P1) - ' + history.p2Wins + ' (P2/CPU)';

    mostrarTela('gameover-screen');
}

function atualizarHUD() {
    const p1Bar = document.getElementById('p1-health');
    const p2Bar = document.getElementById('p2-health');

    p1Bar.style.width = gameState.p1.health + '%';
    p2Bar.style.width = gameState.p2.health + '%';

    p1Bar.style.background = gameState.p1.health < 30 ? '#ff4757' : 'linear-gradient(90deg, #1dd1a1, #10ac84)';
    p2Bar.style.background = gameState.p2.health < 30 ? '#ff4757' : 'linear-gradient(90deg, #1dd1a1, #10ac84)';

    document.getElementById('p1-score').textContent = gameState.p1.score;
    document.getElementById('p2-score').textContent = gameState.p2.score;

    const p1Dots = document.querySelectorAll('#p1-rounds .dot');
    const p2Dots = document.querySelectorAll('#p2-rounds .dot');
    p1Dots.forEach((d, i) => d.classList.toggle('won', i < gameState.p1.roundsWon));
    p2Dots.forEach((d, i) => d.classList.toggle('won', i < gameState.p2.roundsWon));
}

function loopPrincipal() {
    const ctx = gameState.ctx;
    const canvas = gameState.canvas;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    gameState.stage.draw(ctx);

    if (gameState.status === 'FIGHTING') {
        gameState.p1.update(gameState.keys, gameState.p2, 492, canvas.width, gameState.sfx);
        gameState.p2.update(gameState.keys, gameState.p1, 492, canvas.width, gameState.sfx);
        verificarGolpes();
    }

    gameState.p1.draw(ctx);
    gameState.p2.draw(ctx);

    for (let i = gameState.particles.length - 1; i >= 0; i--) {
        const p = gameState.particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, 5, 5);
        if (p.life <= 0) gameState.particles.splice(i, 1);
    }

    requestAnimationFrame(loopPrincipal);
}

// Eventos imediatos do teclado
window.addEventListener('keydown', (e) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
    }
    gameState.keys[e.code] = true;
});

window.addEventListener('keyup', (e) => {
    gameState.keys[e.code] = false;
});

// Carrega o placar salvo assim que o script rodar
atualizarRecordesMenu();